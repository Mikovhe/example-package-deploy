def greeting (name):
    '''
        Take an arguement name and returns
        Hello 'name', how are you?

        '''

    print('Hello '+ name +', how are you?')